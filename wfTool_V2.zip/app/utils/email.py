from flask import url_for, current_app
from flask_mail import Message
from itsdangerous import URLSafeTimedSerializer as Serializer
from app import db, mail
from datetime import datetime, timedelta

def get_reset_token(user, expires_sec=1800):
    s = Serializer(current_app.config['SECRET_KEY'])
    token = s.dumps({'user_id': user.id})
    
    # Store token in database
    user.reset_token = token
    user.reset_token_expiry = datetime.utcnow() + timedelta(seconds=expires_sec)
    db.session.commit()
    
    return token

def verify_reset_token(token):
    s = Serializer(current_app.config['SECRET_KEY'])
    try:
        user_id = s.loads(token)['user_id']
    except:
        return None
    
    from app.models.user import User
    user = User.query.get(user_id)
    if user and user.reset_token == token and user.reset_token_expiry > datetime.utcnow():
        return user
    return None

def send_reset_email(user):
    token = get_reset_token(user)
    msg = Message('Password Reset Request',
                  sender='noreply@demo.com',
                  recipients=[user.email])
    msg.body = f'''To reset your password, visit the following link:
{url_for('auth.reset_token', token=token, _external=True)}

If you did not make this request then simply ignore this email and no changes will be made.
'''
    mail.send(msg)