from functools import wraps
from flask import flash, redirect, url_for
from flask_login import current_user

def check_user_type(user_types):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if current_user.user_type not in user_types:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('cases.dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator