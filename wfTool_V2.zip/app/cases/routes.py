from flask import render_template, url_for, flash, redirect, request, Blueprint, jsonify, send_file
from flask_login import login_required, current_user
from app import db
from app.utils.decorators import check_user_type
from app.models.case_details import CaseDetailsActive, CaseDetailsCompleted
from app.models.request_details import RequestDetailsActive, RequestDetailsCompleted
from app.models.user import User
from app.cases.forms import CaseForm, RequestForm
from app.cases.utils import generate_case_id, generate_tracking_id, generate_request_id
from datetime import datetime
import csv
import io


cases = Blueprint('cases', __name__)

# Role-based status options
MAKER_STATUS_OPTIONS = ['New', 'Maker Validation', 'Pending with Requestor', 'CP Validation']
CHECKER_STATUS_OPTIONS = ['QC 4Eye-Validation', 'CP 4Eye-Validation']
MANAGER_STATUS_OPTIONS = MAKER_STATUS_OPTIONS + CHECKER_STATUS_OPTIONS + ['Completed', 'Rejected']

@cases.route('/')
@cases.route('/dashboard')
@login_required
def dashboard():
    active_cases_count = CaseDetailsActive.query.count()
    completed_cases_count = CaseDetailsCompleted.query.count()
    active_requests_count = RequestDetailsActive.query.count()
    completed_requests_count = RequestDetailsCompleted.query.count()
    
    return render_template('cases/dashboard.html', 
                         title='Dashboard',
                         active_cases_count=active_cases_count,
                         completed_cases_count=completed_cases_count,
                         active_requests_count=active_requests_count,
                         completed_requests_count=completed_requests_count)

@cases.route('/cases/active')
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def active_cases():
    cases = CaseDetailsActive.query.all()
    makers = User.query.filter(User.user_type.in_(['maker', 'manager'])).all()
    checkers = User.query.filter(User.user_type.in_(['checker', 'manager'])).all()
    
    # Get status options based on user role
    status_options = get_status_options(current_user.user_type)
    
    return render_template('cases/case_list.html', 
                         title='Active Cases', 
                         cases=cases, 
                         case_type='active',
                         makers=makers,
                         checkers=checkers,
                         status_options=status_options,
                         user_type=current_user.user_type)

@cases.route('/cases/completed')
@login_required
@check_user_type(['checker', 'manager'])
def completed_cases():
    cases = CaseDetailsCompleted.query.all()
    makers = User.query.filter(User.user_type.in_(['maker', 'manager'])).all()
    checkers = User.query.filter(User.user_type.in_(['checker', 'manager'])).all()
    status_options = get_status_options(current_user.user_type)
    
    return render_template('cases/case_list.html', 
                         title='Completed Cases', 
                         cases=cases, 
                         case_type='completed',
                         makers=makers,
                         checkers=checkers,
                         status_options=status_options,
                         user_type=current_user.user_type)

@cases.route('/case/create', methods=['GET', 'POST'])
@login_required
@check_user_type(['maker', 'manager'])
def create_case():
    form = CaseForm()
    if form.validate_on_submit():
        case = CaseDetailsActive(
            case_id=generate_case_id(),
            tracking_id=generate_tracking_id(),
            issue_type=form.issue_type.data,
            case_status=form.case_status.data,
            maker=form.maker.data,
            checker=form.checker.data,
            maker_comments=form.maker_comments.data,
            checker_comments=form.checker_comments.data,
            priority=form.priority.data,
            created_by=current_user.username,
            due_date=form.due_date.data
        )
        db.session.add(case)
        db.session.commit()
        flash('Case created successfully!', 'success')
        return redirect(url_for('cases.active_cases'))
    
    return render_template('cases/case_form.html', 
                         title='Create Case', 
                         form=form, 
                         form_type='create')

@cases.route('/case/<string:case_id>/requests')
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def get_case_requests(case_id):
    """API endpoint to get requests for a case"""
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        requests = RequestDetailsActive.query.filter_by(case_id=case_id).all()
        requests_data = []
        for req in requests:
            requests_data.append({
                'request_id': req.request_id,
                'request_type': req.request_type,
                'request_description': req.request_description,
                'status': req.status,
                'priority': req.priority,
                'requested_by': req.requested_by,
                'request_date': req.request_date.strftime('%Y-%m-%d'),
                'due_date': req.due_date.strftime('%Y-%m-%d') if req.due_date else '',
                'notes': req.notes
            })
        return jsonify(requests_data)
    return jsonify([])

@cases.route('/case/<string:case_id>/update_field', methods=['POST'])
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def update_case_field(case_id):
    case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    
    field = request.json.get('field')
    value = request.json.get('value')
    
    # Role-based field validation
    if not can_edit_field(current_user.user_type, field, case, value):
        return jsonify({'success': False, 'message': 'You do not have permission to edit this field'}), 403
    
    # Status validation based on role
    if field == 'case_status' and not is_valid_status(current_user.user_type, value):
        return jsonify({'success': False, 'message': 'Invalid status for your role'}), 400
    
    if field in ['case_status', 'maker', 'checker', 'maker_comments', 'checker_comments', 'priority']:
        setattr(case, field, value)
        case.updated_date = datetime.utcnow()
        db.session.commit()
        return jsonify({'success': True, 'message': 'Field updated successfully'})
    
    return jsonify({'success': False, 'message': 'Field not editable'}), 400

@cases.route('/cases/export')
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def export_cases():
    case_type = request.args.get('type', 'active')
    
    if case_type == 'active':
        cases = CaseDetailsActive.query.all()
    else:
        cases = CaseDetailsCompleted.query.all()
    
    # Create CSV data without pandas
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow([
        'Case ID', 'Tracking ID', 'Issue Type', 'Case Status',
        'Maker', 'Checker', 'Maker Comments', 'Checker Comments',
        'Priority', 'Created Date', 'Due Date'
    ])
    
    # Write data
    for case in cases:
        writer.writerow([
            case.case_id,
            case.tracking_id,
            case.issue_type,
            case.case_status,
            case.maker or '',
            case.checker or '',
            case.maker_comments or '',
            case.checker_comments or '',
            case.priority,
            case.created_date.strftime('%Y-%m-%d'),
            case.due_date.strftime('%Y-%m-%d') if case.due_date else ''
        ])
    
    output.seek(0)
    
    # Create bytes buffer for send_file
    mem = io.BytesIO()
    mem.write(output.getvalue().encode('utf-8'))
    mem.seek(0)
    output.close()
    
    return send_file(
        mem,
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'{case_type}_cases_export.csv'
    )

@cases.route('/case/<string:case_id>/complete', methods=['POST'])
@login_required
@check_user_type(['checker', 'manager'])
def complete_case(case_id):
    case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    requests = RequestDetailsActive.query.filter_by(case_id=case_id).all()
    
    # Create completed case
    completed_case = CaseDetailsCompleted(
        # Non-editable fields (copied from active case)
        case_id=case.case_id,
        tracking_id=case.tracking_id,
        issue_type=case.issue_type,
        
        # Editable fields
        case_status='Completed',
        maker=case.maker,
        checker=case.checker,
        maker_comments=case.maker_comments,
        checker_comments=case.checker_comments,
        priority=case.priority,
        created_by=case.created_by,
        created_date=case.created_date,
        completed_date=datetime.utcnow(),
        due_date=case.due_date
    )
    db.session.add(completed_case)
    
    # Move requests to completed database
    for req in requests:
        completed_request = RequestDetailsCompleted(
            request_id=req.request_id,
            case_id=req.case_id,
            request_type=req.request_type,
            request_description=req.request_description,
            requested_by=req.requested_by,
            request_date=req.request_date,
            status='Completed',
            priority=req.priority,
            assigned_to=req.assigned_to,
            due_date=req.due_date,
            completed_date=datetime.utcnow(),
            notes=req.notes
        )
        db.session.add(completed_request)
        db.session.delete(req)
    
    # Delete from active database
    db.session.delete(case)
    db.session.commit()
    
    flash('Case marked as completed!', 'success')
    return redirect(url_for('cases.active_cases'))

@cases.route('/case/<string:case_id>/delete', methods=['POST'])
@login_required
@check_user_type(['manager'])
def delete_case(case_id):
    """
    Transactional delete:
    Deletes a case and all its associated requests.
    If any deletion fails, rollback is performed.
    """
    try:
        case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
        # Fetch associated requests
        requests = RequestDetailsActive.query.filter_by(case_id=case_id).all()

        # Delete requests first
        for req in requests:
            db.session.delete(req)

        # Then delete the case
        db.session.delete(case)

        # Commit both deletions together
        db.session.commit()

        flash(f'Case {case_id} and all associated requests deleted successfully!', 'success')
        return redirect(url_for('cases.active_cases'))

    except Exception as e:
        db.session.rollback()
        flash(f'❌ Failed to delete case {case_id}: {str(e)}. Transaction rolled back.', 'danger')
        return redirect(url_for('cases.active_cases'))


# @cases.route('/case/<string:case_id>/delete', methods=['POST'])
# @login_required
# @check_user_type(['manager'])
# def delete_case(case_id):
#     case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    
#     # Cascade delete will automatically delete related requests
#     db.session.delete(case)
#     db.session.commit()
    
#     flash('Case and associated requests deleted successfully!', 'success')
#     return redirect(url_for('cases.active_cases'))

@cases.route('/case/<string:case_id>/request/create', methods=['GET', 'POST'])
@login_required
@check_user_type(['maker', 'manager'])
def create_request(case_id):
    case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    form = RequestForm()
    
    if form.validate_on_submit():
        request_detail = RequestDetailsActive(
            request_id=form.request_type.data,#generate_request_id(),
            case_id=case_id,
            request_type=form.request_type.data,
            request_description=form.request_description.data,
            requested_by=current_user.username,
            status=form.status.data,
            priority=form.priority.data,
            assigned_to=form.assigned_to.data,
            due_date=form.due_date.data,
            notes=form.notes.data
        )
        db.session.add(request_detail)
        db.session.commit()
        flash('Request created successfully!', 'success')
        return redirect(url_for('cases.active_cases'))
    
    return render_template('cases/request_form.html', 
                         title='Create Request', 
                         form=form, 
                         form_type='create', 
                         case=case)

# ============================================================================
# API ENDPOINTS FOR EXTERNAL ACCESS
# ============================================================================

@cases.route('/api/cases', methods=['POST'])
@login_required
@check_user_type(['maker', 'manager'])
def api_create_case():
    """Create case via JSON API"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    # Validate required fields
    if 'issue_type' not in data:
        return jsonify({'error': 'Missing required field: issue_type'}), 400
    
    try:
        # Parse due_date if provided
        due_date = None
        if data.get('due_date'):
            try:
                due_date = datetime.strptime(data['due_date'], '%Y-%m-%d')
            except ValueError:
                return jsonify({'error': 'Invalid due_date format. Use YYYY-MM-DD'}), 400
        
        case = CaseDetailsActive(
            case_id=generate_case_id(),
            tracking_id=generate_tracking_id(),
            issue_type=data['issue_type'],
            case_status=data.get('case_status', 'New'),
            maker=data.get('maker', current_user.username),
            checker=data.get('checker'),
            maker_comments=data.get('maker_comments'),
            checker_comments=data.get('checker_comments'),
            priority=data.get('priority', 'Medium'),
            created_by=current_user.username,
            due_date=due_date
        )
        
        db.session.add(case)
        db.session.commit()
        
        return jsonify({
            'message': 'Case created successfully',
            'case_id': case.case_id,
            'tracking_id': case.tracking_id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to create case: {str(e)}'}), 500

@cases.route('/api/cases/bulk', methods=['POST'])
@login_required
@check_user_type(['maker', 'manager'])
def bulk_create_cases():
    """Create multiple cases via JSON API"""
    data = request.get_json()
    
    if not data or 'cases' not in data:
        return jsonify({'error': 'No cases data provided'}), 400
    
    created_cases = []
    errors = []
    
    for case_data in data['cases']:
        try:
            # Parse due_date if provided
            due_date = None
            if case_data.get('due_date'):
                try:
                    due_date = datetime.strptime(case_data['due_date'], '%Y-%m-%d')
                except ValueError:
                    errors.append(f"Invalid due_date format for case: {case_data.get('issue_type', 'Unknown')}")
                    continue
            
            case = CaseDetailsActive(
                case_id=generate_case_id(),
                tracking_id=generate_tracking_id(),
                issue_type=case_data.get('issue_type'),
                case_status=case_data.get('case_status', 'New'),
                maker=case_data.get('maker', current_user.username),
                checker=case_data.get('checker'),
                maker_comments=case_data.get('maker_comments'),
                checker_comments=case_data.get('checker_comments'),
                priority=case_data.get('priority', 'Medium'),
                created_by=current_user.username,
                due_date=due_date
            )
            db.session.add(case)
            created_cases.append({
                'case_id': case.case_id,
                'tracking_id': case.tracking_id,
                'issue_type': case.issue_type
            })
            
        except Exception as e:
            errors.append(f"Error creating case '{case_data.get('issue_type', 'Unknown')}': {str(e)}")
    
    if errors:
        db.session.rollback()
        return jsonify({'errors': errors}), 400
    
    db.session.commit()
    
    return jsonify({
        'message': f'Successfully created {len(created_cases)} cases',
        'created_cases': created_cases
    }), 201

@cases.route('/api/requests', methods=['POST'])
@login_required
@check_user_type(['maker', 'manager'])
def api_create_request():
    """Create request via JSON API"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    # Validate required fields
    required_fields = ['case_id', 'request_type', 'request_description']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    # Check if case exists
    case = CaseDetailsActive.query.filter_by(case_id=data['case_id']).first()
    if not case:
        return jsonify({'error': f"Case not found: {data['case_id']}"}), 404
    
    try:
        # Parse due_date if provided
        due_date = None
        if data.get('due_date'):
            try:
                due_date = datetime.strptime(data['due_date'], '%Y-%m-%d')
            except ValueError:
                return jsonify({'error': 'Invalid due_date format. Use YYYY-MM-DD'}), 400
        
        request_detail = RequestDetailsActive(
            request_id=data['request_id'],
            case_id=data['case_id'],
            request_type=data['request_type'],
            request_description=data['request_description'],
            requested_by=current_user.username,
            status=data.get('status', 'Pending'),
            priority=data.get('priority', 'Medium'),
            assigned_to=data.get('assigned_to'),
            due_date=due_date,
            notes=data.get('notes')
        )
        
        db.session.add(request_detail)
        db.session.commit()
        
        return jsonify({
            'message': 'Request created successfully',
            'request_id': request_detail.request_id,
            'case_id': request_detail.case_id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to create request: {str(e)}'}), 500

@cases.route('/api/test-create', methods=['POST'])
@login_required
def test_create_case():
    """Test endpoint that doesn't require manual cookie handling"""
    data = request.get_json()
    
    case = CaseDetailsActive(
        case_id=generate_case_id(),
        tracking_id=generate_tracking_id(),
        issue_type=data.get('issue_type', 'Test Issue'),
        case_status='New',
        maker=current_user.username,
        priority='Medium',
        created_by=current_user.username
    )
    
    db.session.add(case)
    db.session.commit()
    
    return jsonify({
        'message': 'Test case created successfully!',
        'case_id': case.case_id
    })

@cases.route('/test-api')
@login_required
def test_api():
    """Test page for API endpoints"""
    return render_template('cases/test_api.html')

@cases.route('/api/debug/auth', methods=['GET'])
def debug_auth():
    """Debug authentication status"""
    if current_user.is_authenticated:
        return jsonify({
            'authenticated': True,
            'user': current_user.username,
            'role': current_user.user_type
        })
    else:
        return jsonify({
            'authenticated': False,
            'message': 'Not logged in'
        })

@cases.route('/api/status', methods=['GET'])
@login_required
def api_status():
    """Simple API status check"""
    return jsonify({
        'status': 'API is working',
        'user': current_user.username,
        'role': current_user.user_type,
        'timestamp': datetime.utcnow().isoformat()
    })


# @cases.route('/case/<string:case_id>/delete', methods=['POST'])
# @login_required
# @check_user_type(['manager'])
# def delete_case(case_id):
#     """Delete a case and all its requests in a single transactional operation"""
#     try:
#         case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
#         requests = RequestDetailsActive.query.filter_by(case_id=case_id).all()

#         # Delete all requests first
#         for req in requests:
#             db.session.delete(req)

#         # Delete the case
#         db.session.delete(case)

#         # Commit everything together
#         db.session.commit()
#         flash(f'Case {case_id} and all associated requests deleted successfully!', 'success')
#         return redirect(url_for('cases.active_cases'))

#     except Exception as e:
#         db.session.rollback()
#         flash(f'❌ Failed to delete case {case_id}. Transaction rolled back. Error: {str(e)}', 'danger')
#         return redirect(url_for('cases.active_cases'))
    

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def can_edit_field(user_type, field, case, value):
    """Check if user can edit specific field based on role"""
    if user_type == 'manager':
        return True
    
    if field == 'maker_comments' and user_type == 'maker':
        return True
    
    if field == 'checker_comments' and user_type == 'checker':
        return True
    
    if field == 'case_status':
        if user_type == 'maker' and value in MAKER_STATUS_OPTIONS:
            return True
        if user_type == 'checker' and value in CHECKER_STATUS_OPTIONS:
            return True
    
    if field == 'maker' and user_type == 'manager':
        return True
    
    if field == 'checker' and user_type == 'manager':
        return True
    
    if field == 'priority' and user_type in ['maker', 'checker']:
        return True
    
    return False

def is_valid_status(user_type, status):
    """Validate status based on user role"""
    if user_type == 'manager':
        return status in MANAGER_STATUS_OPTIONS
    elif user_type == 'maker':
        return status in MAKER_STATUS_OPTIONS
    elif user_type == 'checker':
        return status in CHECKER_STATUS_OPTIONS
    return False

def get_status_options(user_type):
    """Get status options based on user role"""
    if user_type == 'manager':
        return MANAGER_STATUS_OPTIONS
    elif user_type == 'maker':
        return MAKER_STATUS_OPTIONS
    elif user_type == 'checker':
        return CHECKER_STATUS_OPTIONS
    return []