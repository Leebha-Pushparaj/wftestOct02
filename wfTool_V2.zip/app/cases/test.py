import os
from pathlib import Path

path = Path(os.path.abspath(__file__))

# Go two levels up
two_levels_up = path.parents[1]/"instance"

print(two_levels_up)
# Use relative path to active_cases.db
db_path = two_levels_up / 'active_cases.db'