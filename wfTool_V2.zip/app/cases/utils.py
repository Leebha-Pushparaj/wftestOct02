import uuid
from datetime import datetime
from sqlalchemy import create_engine, select, func, MetaData
import os
from pathlib import Path

def generate_case_id():
    """Generate new case ID with sequential numbering based on existing records"""
    try:
        
        path = Path(os.path.abspath(__file__))
        # Go two levels up
        two_levels_up = path.parents[2]/"instance"
        # Use relative path to active_cases.db
        db_path = str(two_levels_up / 'active_cases.db')
 
        # Check if database exists
        if not os.path.exists(db_path):
            print("Database file not found, creating first case ID")
            NewID = ("00"+str(datetime.today().year))[-1:] + ("00"+str(datetime.today().month))[-2:] + "001"
            return "BRR" + str(NewID)
        
        engine = create_engine(f'sqlite:///{db_path}')
        connection = engine.connect()
        metadata = MetaData()
        metadata.reflect(bind=engine)

        # Check if table exists
        if 'case_details' not in metadata.tables:
            print("case_details table not found, creating first case ID")
            connection.close()
            NewID = ("00"+str(datetime.today().year))[-1:] + ("00"+str(datetime.today().month))[-2:] + "001"
            return "BRR" + str(NewID)

        sel_case_actattributes = metadata.tables['case_details']

        # Get the maximum case_id
        lstCaseId = connection.scalar(select(func.max(sel_case_actattributes.c.case_id)))
        print(f"Latest Case ID Identified from Case Table: {lstCaseId}")
        connection.close()
        
        current_year_month = ("00"+str(datetime.today().year))[-1:] + ("00"+str(datetime.today().month))[-2:]
        
        if lstCaseId:
            # Extract numeric part and increment
            if lstCaseId.startswith("BRR") and len(lstCaseId) > 3:
                numeric_part = lstCaseId[3:]
                if numeric_part.startswith(current_year_month):
                    # Increment the sequence number
                    sequence_part = numeric_part[3:]  # Get the last 5 digits
                    try:
                        new_sequence = int(sequence_part) + 1
                        NewID = current_year_month + str(new_sequence).zfill(3)
                    except ValueError:
                        NewID = current_year_month + "001"
                else:
                    # Different year/month, start new sequence
                    NewID = current_year_month + "001"
            else:
                # Invalid format, start new sequence
                NewID = current_year_month + "001"
        else:
            # No existing cases, start with 001
            NewID = current_year_month + "001"

    except Exception as e:
        print(f"Error reading case details from Database: {e}")
        current_year_month = ("00"+str(datetime.today().year))[-1:] + ("00"+str(datetime.today().month))[-2:]
        NewID = current_year_month + "001"

    return "BRR" + NewID

def generate_tracking_id():
    return f"TRK-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"

def generate_request_id():
    return f"REQ-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"

