import numpy as np, pandas as pd
import requests, json, sys, os
import time, random
from datetime import datetime, timedelta
from pathlib import Path

class CompleteCaseManagementAPI:
    def __init__(self, base_url):
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

    def generate_unique_case_id(self):
        """Generate a unique case ID"""
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        random_suffix = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=6))
        return f"CASE-{timestamp}-{random_suffix}"

    def debug_login_process(self, email, password):
        """Step-by-step login process with CSRF handling"""
        print("🔍 DEBUGGING LOGIN PROCESS")
        print("=" * 60)

        # Step 1: Get login page
        login_page = self.session.get(f'{self.base_url}/login')
        print(f"Login page status: {login_page.status_code}")

        # Extract CSRF token
        csrf_token = self.extract_csrf_token(login_page.text)
        print(f"CSRF token found: {bool(csrf_token)}")

        # Prepare login data
        login_data = {'email': email, 'password': password}
        if csrf_token:
            login_data['csrf_token'] = csrf_token

        # Step 2: Submit login
        response = self.session.post(
            f'{self.base_url}/login',
            data=login_data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            allow_redirects=False
        )

        print(f"Login response: {response.status_code}")

        if response.status_code in [301, 302]:
            location = response.headers.get('Location', '')
            if 'dashboard' in location:
                print("✅ Login successful!")
                return True
            elif 'login' in location:
                print("❌ Login failed - redirected back to login")
                return False
        elif response.status_code == 200 and 'dashboard' not in response.url.lower():
            print("❌ Still on login page - incorrect credentials")
            return False

        print("✅ Login verified successfully")
        return True

    def verify_session(self):
        """Verify active session"""
        response = self.session.get(f'{self.base_url}/dashboard', allow_redirects=False)
        return response.status_code == 200 or (
            response.status_code in [301, 302] and 'login' not in response.headers.get('Location', '')
        )

    def create_case_via_api(self, case_data):
        """Create a new case via API"""
        print("\n📝 Creating case via API")
        print("-" * 40)

        if not self.verify_session():
            print("❌ Session invalid, cannot proceed")
            return None

        form_page = self.session.get(f'{self.base_url}/case/create')
        csrf_token = self.extract_csrf_token(form_page.text)

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
        if csrf_token:
            headers['X-CSRF-Token'] = csrf_token

        response = self.session.post(
            f'{self.base_url}/api/cases',
            json=case_data,
            headers=headers,
            allow_redirects=False
        )

        print(f"Response status: {response.status_code}")

        if response.status_code == 201:
            result = response.json()
            print(f"✅ Case created successfully: {result.get('case_id')}")
            return result
        else:
            print(f"❌ Failed to create case: {response.text[:200]}...")
            return None

    def create_multiple_requests_via_api(self, case_id, requests_list):
        """Create multiple requests for one case via API"""
        print("\n📋 Creating multiple requests for the case")
        print("=" * 60)

        if not self.verify_session():
            print("❌ Session invalid, cannot proceed")
            return None

        form_page = self.session.get(f'{self.base_url}/case/create')
        csrf_token = self.extract_csrf_token(form_page.text)

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
        if csrf_token:
            headers['X-CSRF-Token'] = csrf_token

        success_count = 0
        for i, req_data in enumerate(requests_list, start=1):
            req_data['case_id'] = case_id
            print(f"➡️ Creating request #{i} for case {case_id} ...")
            response = self.session.post(
                f'{self.base_url}/api/requests',
                json=req_data,
                headers=headers,
                allow_redirects=False
            )

            if response.status_code == 201:
                result = response.json()
                print(f"✅ Request {i} created: {result.get('request_id')}")
                success_count += 1
            else:
                print(f"❌ Failed to create request {i}: {response.text[:200]}")

            time.sleep(0.3)  # small delay between requests for safety

        print(f"\n📦 Summary: {success_count}/{len(requests_list)} requests created successfully.")
        return success_count

    def extract_csrf_token(self, html):
        """Extract CSRF token"""
        import re
        match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html)
        return match.group(1) if match else None


    def delete_case_via_api(self, case_id):
        """Delete a case via API (for rollback if requests fail)."""
        print(f"\n🗑️ Rolling back case {case_id} due to failed request creation...")

        headers = {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
        response = self.session.delete(f'{self.base_url}/api/cases/{case_id}', headers=headers)

        if response.status_code == 200:
            print(f"✅ Case {case_id} deleted successfully (rollback complete).")
            return True
        else:
            print(f"⚠️ Failed to delete case {case_id}. Manual cleanup may be needed.")
            print(f"Response: {response.text[:200]}")
            return False
    
    def create_case_with_requests(self, case_data, request_list):
        """
        Create a case and multiple requests transactionally.
        If any request fails, rollback the case and already created requests.
        """
        print("\nSTEP 2: CREATE CASE + REQUESTS (TRANSACTIONAL)")
        print("=" * 60)
    
        # Step 1: Create case
        case_result = self.create_case_via_api(case_data)
        if not case_result:
            print("❌ Case creation failed. Cannot proceed.")
            return False
    
        case_id = case_result.get('case_id')
        print(f"✅ Case created successfully with ID: {case_id}")
    
        # Step 2: Create requests
        success_count = 0
        created_requests = []
    
        form_page = self.session.get(f'{self.base_url}/case/create')
        csrf_token = self.extract_csrf_token(form_page.text)
    
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
        if csrf_token:
            headers['X-CSRF-Token'] = csrf_token
    
        for i, req_data in enumerate(request_list, start=1):
            req_data['case_id'] = case_id
            print(f"➡️ Creating request #{i} for case {case_id} ...")
            response = self.session.post(
                f'{self.base_url}/api/requests',  # API endpoint for requests
                json=req_data,
                headers=headers,
                allow_redirects=False
            )
    
            if response.status_code == 201:
                result = response.json()
                created_requests.append(result.get('request_id'))
                print(f"✅ Request {i} created: {result.get('request_id')}")
                success_count += 1
            else:
                print(f"❌ Failed to create request {i}: {response.text[:200]}")
                break  # Stop creating further requests on first failure
    
            time.sleep(0.2)  # short delay
    
        # Step 3: Rollback if not all requests created
        if success_count != len(request_list):
            print(f"\n🗑️ Rolling back case {case_id} due to failed request creation...")
    
            # Delete requests that were already created
            for req_id in created_requests:
                try:
                    del_resp = self.session.delete(
                        f'{self.base_url}/api/requests/{req_id}',  # optional: if API exists
                        headers=headers
                    )
                except Exception as e:
                    print(f"⚠️ Failed to delete request {req_id}: {str(e)}")
    
            # Delete the case itself (make sure URL matches blueprint prefix)
            delete_url = f'{self.base_url}/cases/case/{case_id}/delete'
            try:
                del_case_resp = self.session.post(delete_url, headers=headers)
                if del_case_resp.status_code in [200, 302]:
                    print(f"✅ Case {case_id} deleted successfully.")
                else:
                    print(f"⚠️ Failed to delete case {case_id}. Manual cleanup may be needed.")
            except Exception as e:
                print(f"⚠️ Exception during case deletion: {str(e)}")
    
            print("🚨 Transaction rolled back.")
            return False
    
        print(f"\n✅ All {success_count} requests created successfully for case {case_id}.")
        return True
            
def read_csv_to_dict_list(csv_path):
    """
    Reads a CSV file and converts it into a clean list of dictionaries.
    - Replaces NaN/Inf values with None
    - Trims string fields
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"❌ File not found: {csv_path}")

    df = pd.read_csv(csv_path)

    # Replace problematic values
    df.replace({np.nan: None, np.inf: None, -np.inf: None}, inplace=True)

    # Optional: strip whitespace from string columns
    for col in df.select_dtypes(include=['object']).columns:
        df[col] = df[col].apply(lambda x: x.strip() if isinstance(x, str) else x)

    records = df.to_dict(orient="records")

    print(f"✅ Loaded and sanitized {len(records)} records from {csv_path}")
    return records
    


def normalize_case_dates(records, date_columns=None):
    """
    Normalize multiple date columns to standard formats.
    Converts:
      - Date fields → YYYY-MM-DD
      - Datetime fields → YYYY-MM-DD HH:MM:SS
    :param records: List of dictionaries (records)
    :param date_columns: Optional list of column names to check and normalize
    :return: Updated records list with normalized date formats
    """
    from datetime import datetime

    # Default list if none provided
    if date_columns is None:
        date_columns = ['due_date'] #, 'created_at', 'updated_at', 'resolved_at', 'closed_at']

    # Go through each record
    for rec in records:
        for col in date_columns:
            if col in rec and rec[col]:
                val = str(rec[col]).strip()
                if not val:
                    continue

                # Try multiple known formats
                parsed = None
                for fmt in ("%m/%d/%Y", "%d/%m/%Y", "%Y-%m-%d",
                            "%m/%d/%Y %H:%M", "%d/%m/%Y %H:%M",
                            "%Y-%m-%d %H:%M:%S"):
                    try:
                        parsed = datetime.strptime(val, fmt)
                        break
                    except ValueError:
                        continue

                if parsed:
                    # If time present → full datetime; else → date only
                    if parsed.hour or parsed.minute or parsed.second:
                        rec[col] = parsed.strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        rec[col] = parsed.strftime("%Y-%m-%d")
                else:
                    print(f"⚠️ Skipped unrecognized date format in '{col}': {val}")

    return records

def main():
    BASE_URL = "http://localhost:5000"
    EMAIL = "pushparajemails@gmail.com"
    PASSWORD = "Admin@1234"
    cacheDIR = "C:\\Users\\pushp\\Dev\\Conda\\envs\\flask-brrwf\\"
    
    print("🚀 CASE MANAGEMENT API CLIENT (Single Case, Multiple Requests)")
    print("=" * 60)
    
    api_client = CompleteCaseManagementAPI(BASE_URL)
    
    # Step 1: Login
    print("\nSTEP 1: LOGIN")
    print("=" * 60)
    if not api_client.debug_login_process(EMAIL, PASSWORD):
        print("❌ Login failed. Exiting.")
        sys.exit(1)
    
    case_records = read_csv_to_dict_list(cacheDIR+"cases.csv")
    case_records = normalize_case_dates(case_records)
    request_records = read_csv_to_dict_list(cacheDIR+"requests.csv")
    request_records = normalize_case_dates(request_records)
    
    success = api_client.create_case_with_requests(case_records[0], request_records)
    
    if not success:
        print("❌ Process failed: All changes rolled back.")
    else:
        print("\n✅ Process complete.")
        print(f"🌐 Visit: {BASE_URL}/cases/active to verify records.")


if __name__ == "__main__":
    main()
