from app import create_app, db
import socket

def get_ip_address():
    """Get the local IP address"""
    try:
        # Connect to a remote address to determine local IP
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except:
        return "127.0.0.1"

def get_hostname():
    """Get the computer hostname"""
    try:
        return socket.gethostname()
    except:
        return "localhost"

app = create_app()

def initialize_databases():
    """Initialize all database tables"""
    with app.app_context():
        try:
            # Method 1: Try the modern approach first
            print("🔄 Initializing databases...")
            
            # Create all tables including binds
            db.create_all()
            
            print("✅ Main database tables created")
            print("✅ Bind database tables created (active_cases, completed_cases)")
            print("📊 Database URI:", app.config["SQLALCHEMY_DATABASE_URI"])
            print("📊 Active cases DB:", app.config["SQLALCHEMY_BINDS"]["active_cases"])
            print("📊 Completed cases DB:", app.config["SQLALCHEMY_BINDS"]["completed_cases"])

        except Exception as e:
            print(f"❌ Database error: {e}")
            print("💡 The tables will be created when first accessed")

if __name__ == '__main__':
    initialize_databases()
    
    host = '0.0.0.0'  # Listen on all interfaces
    port = 5000
    
    local_ip = get_ip_address()
    hostname = get_hostname()
    
    print("🚀 Flask Case Management System")
    print("=" * 50)
    print(f"📡 Server starting...")
    print(f"🔧 Host: {host}")
    print(f"🔧 Port: {port}")
    print(f"🌐 Access URLs:")
    print(f"   Local: http://127.0.0.1:{port}")
    print(f"   Local IP: http://{local_ip}:{port}")
    print(f"   Hostname: http://{hostname}.local:{port} (if supported)")
    print("=" * 50)
    
    app.run(host=host, port=port, debug=True)