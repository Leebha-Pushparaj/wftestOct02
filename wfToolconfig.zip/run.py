from app import create_app, db
from app.models.user import User
from app.models.case_details import CaseDetailsActive, CaseDetailsCompleted
from app.models.request_details import RequestDetailsActive, RequestDetailsCompleted

app = create_app()

def create_tables_for_bind(bind_key, model_classes):
    """Create tables for a specific database bind"""
    with app.app_context():
        # Set the bind key for this operation
        engine = db.get_engine(app, bind=bind_key)
        for model_class in model_classes:
            if hasattr(model_class, '__table__'):
                model_class.__table__.create(bind=engine, checkfirst=True)

with app.app_context():
    try:
        # Main database (users)
        db.create_all()
        print("✅ Main database tables created")
        
        # Active cases database
        active_models = [CaseDetailsActive, RequestDetailsActive]
        create_tables_for_bind('active_cases', active_models)
        print("✅ Active cases database tables created")
        
        # Completed cases database
        completed_models = [CaseDetailsCompleted, RequestDetailsCompleted]
        create_tables_for_bind('completed_cases', completed_models)
        print("✅ Completed cases database tables created")
        
        print("🎉 All database tables initialized successfully!")
        
    except Exception as e:
        print(f"❌ Error creating database tables: {e}")

if __name__ == '__main__':
    app.run(debug=True)