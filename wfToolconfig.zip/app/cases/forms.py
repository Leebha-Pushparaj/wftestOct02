from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, DateField, SubmitField
from wtforms.validators import DataRequired, Length, Optional
from app.models.user import User

class CaseForm(FlaskForm):
    # Non-editable fields (display only, will be auto-generated)
    issue_type = SelectField('Issue Type', 
                           choices=[('', 'Select Issue Type'),
                                   ('Technical', 'Technical'),
                                   ('Billing', 'Billing'),
                                   ('Service', 'Service'),
                                   ('Complaint', 'Complaint'),
                                   ('Inquiry', 'Inquiry'),
                                   ('Other', 'Other')],
                           validators=[DataRequired()])
    
    # Listbox input fields
    case_status = SelectField('Case Status',
                             choices=[('New', 'New'),
                                     ('Maker Validation', 'Maker Validation'),
                                     ('Pending with Requestor', 'Pending with Requestor'),
                                     ('CP Validation', 'CP Validation'),
                                     ('QC 4Eye-Validation', 'QC 4Eye-Validation'),
                                     ('CP 4Eye-Validation', 'CP 4Eye-Validation')],
                             validators=[DataRequired()])
    
    maker = SelectField('Maker', coerce=str, validators=[DataRequired()])
    checker = SelectField('Checker', coerce=str, validators=[Optional()])
    
    # Free text editable fields
    maker_comments = TextAreaField('Maker Comments')
    checker_comments = TextAreaField('Checker Comments')
    
    # Additional fields
    priority = SelectField('Priority',
                          choices=[('Low', 'Low'),
                                  ('Medium', 'Medium'),
                                  ('High', 'High'),
                                  ('Critical', 'Critical')],
                          validators=[DataRequired()])
    due_date = DateField('Due Date', format='%Y-%m-%d', validators=[Optional()])
    
    submit = SubmitField('Save Case')

    def __init__(self, *args, **kwargs):
        super(CaseForm, self).__init__(*args, **kwargs)
        # Populate maker and checker choices from users
        makers = User.query.filter(User.user_type.in_(['maker', 'manager'])).all()
        checkers = User.query.filter(User.user_type.in_(['checker', 'manager'])).all()
        
        self.maker.choices = [('', 'Select Maker')] + [(user.username, user.username) for user in makers]
        self.checker.choices = [('', 'Select Checker')] + [(user.username, user.username) for user in checkers]

class RequestForm(FlaskForm):
    request_type = SelectField('Request Type',
                              choices=[('', 'Select Request Type'),
                                      ('Information', 'Information'),
                                      ('Approval', 'Approval'),
                                      ('Review', 'Review'),
                                      ('Clarification', 'Clarification'),
                                      ('Other', 'Other')],
                              validators=[DataRequired()])
    request_description = TextAreaField('Request Description', validators=[DataRequired()])
    status = SelectField('Status',
                        choices=[('Pending', 'Pending'),
                                ('In Progress', 'In Progress'),
                                ('Completed', 'Completed'),
                                ('Rejected', 'Rejected')],
                        validators=[DataRequired()])
    priority = SelectField('Priority',
                          choices=[('Low', 'Low'),
                                  ('Medium', 'Medium'),
                                  ('High', 'High'),
                                  ('Critical', 'Critical')])
    assigned_to = StringField('Assigned To', validators=[Length(max=100)])
    due_date = DateField('Due Date', format='%Y-%m-%d')
    notes = TextAreaField('Notes')
    submit = SubmitField('Save Request')