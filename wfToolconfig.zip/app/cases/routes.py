from flask import render_template, url_for, flash, redirect, request, Blueprint, jsonify, send_file
from flask_login import login_required, current_user
from app import db
from app.utils.decorators import check_user_type
from app.models.case_details import CaseDetailsActive, CaseDetailsCompleted
from app.models.request_details import RequestDetailsActive, RequestDetailsCompleted
from app.models.user import User
from app.cases.forms import CaseForm, RequestForm
from app.cases.utils import generate_case_id, generate_tracking_id, generate_request_id
from datetime import datetime
import pandas as pd
import io

cases = Blueprint('cases', __name__)

# Role-based status options
MAKER_STATUS_OPTIONS = ['New', 'Maker Validation', 'Pending with Requestor', 'CP Validation']
CHECKER_STATUS_OPTIONS = ['QC 4Eye-Validation', 'CP 4Eye-Validation']
MANAGER_STATUS_OPTIONS = MAKER_STATUS_OPTIONS + CHECKER_STATUS_OPTIONS + ['Completed', 'Rejected']

@cases.route('/')
@cases.route('/dashboard')
@login_required
def dashboard():
    active_cases_count = CaseDetailsActive.query.count()
    completed_cases_count = CaseDetailsCompleted.query.count()
    active_requests_count = RequestDetailsActive.query.count()
    completed_requests_count = RequestDetailsCompleted.query.count()
    
    return render_template('cases/dashboard.html', 
                         title='Dashboard',
                         active_cases_count=active_cases_count,
                         completed_cases_count=completed_cases_count,
                         active_requests_count=active_requests_count,
                         completed_requests_count=completed_requests_count)

@cases.route('/cases/active')
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def active_cases():
    cases = CaseDetailsActive.query.all()
    makers = User.query.filter(User.user_type.in_(['maker', 'manager'])).all()
    checkers = User.query.filter(User.user_type.in_(['checker', 'manager'])).all()
    
    # Get status options based on user role
    status_options = get_status_options(current_user.user_type)
    
    return render_template('cases/case_list.html', 
                         title='Active Cases', 
                         cases=cases, 
                         case_type='active',
                         makers=makers,
                         checkers=checkers,
                         status_options=status_options,
                         user_type=current_user.user_type)

@cases.route('/cases/completed')
@login_required
@check_user_type(['checker', 'manager'])
def completed_cases():
    cases = CaseDetailsCompleted.query.all()
    makers = User.query.filter(User.user_type.in_(['maker', 'manager'])).all()
    checkers = User.query.filter(User.user_type.in_(['checker', 'manager'])).all()
    status_options = get_status_options(current_user.user_type)
    
    return render_template('cases/case_list.html', 
                         title='Completed Cases', 
                         cases=cases, 
                         case_type='completed',
                         makers=makers,
                         checkers=checkers,
                         status_options=status_options,
                         user_type=current_user.user_type)

@cases.route('/case/create', methods=['GET', 'POST'])
@login_required
@check_user_type(['maker', 'manager'])
def create_case():
    form = CaseForm()
    if form.validate_on_submit():
        case = CaseDetailsActive(
            case_id=generate_case_id(),
            tracking_id=generate_tracking_id(),
            issue_type=form.issue_type.data,
            case_status=form.case_status.data,
            maker=form.maker.data,
            checker=form.checker.data,
            maker_comments=form.maker_comments.data,
            checker_comments=form.checker_comments.data,
            priority=form.priority.data,
            created_by=current_user.username,
            due_date=form.due_date.data
        )
        db.session.add(case)
        db.session.commit()
        flash('Case created successfully!', 'success')
        return redirect(url_for('cases.active_cases'))
    
    return render_template('cases/case_form.html', 
                         title='Create Case', 
                         form=form, 
                         form_type='create')

@cases.route('/case/<string:case_id>/requests')
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def get_case_requests(case_id):
    """API endpoint to get requests for a case"""
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        requests = RequestDetailsActive.query.filter_by(case_id=case_id).all()
        requests_data = []
        for req in requests:
            requests_data.append({
                'request_id': req.request_id,
                'request_type': req.request_type,
                'request_description': req.request_description,
                'status': req.status,
                'priority': req.priority,
                'requested_by': req.requested_by,
                'request_date': req.request_date.strftime('%Y-%m-%d'),
                'due_date': req.due_date.strftime('%Y-%m-%d') if req.due_date else '',
                'notes': req.notes
            })
        return jsonify(requests_data)
    return jsonify([])

@cases.route('/case/<string:case_id>/update_field', methods=['POST'])
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def update_case_field(case_id):
    case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    
    field = request.json.get('field')
    value = request.json.get('value')
    
    # Role-based field validation
    if not can_edit_field(current_user.user_type, field, case, value):
        return jsonify({'success': False, 'message': 'You do not have permission to edit this field'}), 403
    
    # Status validation based on role
    if field == 'case_status' and not is_valid_status(current_user.user_type, value):
        return jsonify({'success': False, 'message': 'Invalid status for your role'}), 400
    
    if field in ['case_status', 'maker', 'checker', 'maker_comments', 'checker_comments', 'priority']:
        setattr(case, field, value)
        case.updated_date = datetime.utcnow()
        db.session.commit()
        return jsonify({'success': True, 'message': 'Field updated successfully'})
    
    return jsonify({'success': False, 'message': 'Field not editable'}), 400

def can_edit_field(user_type, field, case, value):
    """Check if user can edit specific field based on role"""
    if user_type == 'manager':
        return True
    
    if field == 'maker_comments' and user_type == 'maker':
        return True
    
    if field == 'checker_comments' and user_type == 'checker':
        return True
    
    if field == 'case_status':
        if user_type == 'maker' and value in MAKER_STATUS_OPTIONS:
            return True
        if user_type == 'checker' and value in CHECKER_STATUS_OPTIONS:
            return True
    
    if field == 'maker' and user_type == 'manager':
        return True
    
    if field == 'checker' and user_type == 'manager':
        return True
    
    if field == 'priority' and user_type in ['maker', 'checker']:
        return True
    
    return False

def is_valid_status(user_type, status):
    """Validate status based on user role"""
    if user_type == 'manager':
        return status in MANAGER_STATUS_OPTIONS
    elif user_type == 'maker':
        return status in MAKER_STATUS_OPTIONS
    elif user_type == 'checker':
        return status in CHECKER_STATUS_OPTIONS
    return False

def get_status_options(user_type):
    """Get status options based on user role"""
    if user_type == 'manager':
        return MANAGER_STATUS_OPTIONS
    elif user_type == 'maker':
        return MAKER_STATUS_OPTIONS
    elif user_type == 'checker':
        return CHECKER_STATUS_OPTIONS
    return []

@cases.route('/cases/export')
@login_required
@check_user_type(['maker', 'checker', 'manager'])
def export_cases():
    case_type = request.args.get('type', 'active')
    
    if case_type == 'active':
        cases = CaseDetailsActive.query.all()
    else:
        cases = CaseDetailsCompleted.query.all()
    
    # Convert to DataFrame
    data = []
    for case in cases:
        data.append({
            'Case ID': case.case_id,
            'Tracking ID': case.tracking_id,
            'Issue Type': case.issue_type,
            'Case Status': case.case_status,
            'Maker': case.maker,
            'Checker': case.checker,
            'Maker Comments': case.maker_comments,
            'Checker Comments': case.checker_comments,
            'Priority': case.priority,
            'Created Date': case.created_date.strftime('%Y-%m-%d'),
            'Due Date': case.due_date.strftime('%Y-%m-%d') if case.due_date else ''
        })
    
    df = pd.DataFrame(data)
    
    # Create Excel file in memory
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Cases', index=False)
    
    output.seek(0)
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'{case_type}_cases_export.xlsx'
    )

@cases.route('/case/<string:case_id>/complete', methods=['POST'])
@login_required
@check_user_type(['checker', 'manager'])
def complete_case(case_id):
    case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    requests = RequestDetailsActive.query.filter_by(case_id=case_id).all()
    
    # Create completed case
    completed_case = CaseDetailsCompleted(
        # Non-editable fields (copied from active case)
        case_id=case.case_id,
        tracking_id=case.tracking_id,
        issue_type=case.issue_type,
        
        # Editable fields
        case_status='Completed',
        maker=case.maker,
        checker=case.checker,
        maker_comments=case.maker_comments,
        checker_comments=case.checker_comments,
        priority=case.priority,
        created_by=case.created_by,
        created_date=case.created_date,
        completed_date=datetime.utcnow(),
        due_date=case.due_date
    )
    db.session.add(completed_case)
    
    # Move requests to completed database
    for req in requests:
        completed_request = RequestDetailsCompleted(
            request_id=req.request_id,
            case_id=req.case_id,
            request_type=req.request_type,
            request_description=req.request_description,
            requested_by=req.requested_by,
            request_date=req.request_date,
            status='Completed',
            priority=req.priority,
            assigned_to=req.assigned_to,
            due_date=req.due_date,
            completed_date=datetime.utcnow(),
            notes=req.notes
        )
        db.session.add(completed_request)
        db.session.delete(req)
    
    # Delete from active database
    db.session.delete(case)
    db.session.commit()
    
    flash('Case marked as completed!', 'success')
    return redirect(url_for('cases.active_cases'))

@cases.route('/case/<string:case_id>/delete', methods=['POST'])
@login_required
@check_user_type(['manager'])
def delete_case(case_id):
    case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    
    # Cascade delete will automatically delete related requests
    db.session.delete(case)
    db.session.commit()
    
    flash('Case and associated requests deleted successfully!', 'success')
    return redirect(url_for('cases.active_cases'))

@cases.route('/case/<string:case_id>/request/create', methods=['GET', 'POST'])
@login_required
@check_user_type(['maker', 'manager'])
def create_request(case_id):
    case = CaseDetailsActive.query.filter_by(case_id=case_id).first_or_404()
    form = RequestForm()
    
    if form.validate_on_submit():
        request_detail = RequestDetailsActive(
            request_id=generate_request_id(),
            case_id=case_id,
            request_type=form.request_type.data,
            request_description=form.request_description.data,
            requested_by=current_user.username,
            status=form.status.data,
            priority=form.priority.data,
            assigned_to=form.assigned_to.data,
            due_date=form.due_date.data,
            notes=form.notes.data
        )
        db.session.add(request_detail)
        db.session.commit()
        flash('Request created successfully!', 'success')
        return redirect(url_for('cases.active_cases'))
    
    return render_template('cases/request_form.html', 
                         title='Create Request', 
                         form=form, 
                         form_type='create', 
                         case=case)