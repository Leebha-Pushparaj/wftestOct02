from app import db
from datetime import datetime

class RequestDetailsActive(db.Model):
    __bind_key__ = 'active_cases'  # Use active_cases database
    __tablename__ = 'request_details'
    
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.String(50), unique=True, nullable=False)
    case_id = db.Column(db.String(50), db.ForeignKey('case_details.case_id'), nullable=False)
    request_type = db.Column(db.String(100), nullable=False)
    request_description = db.Column(db.Text)
    requested_by = db.Column(db.String(100))
    request_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='Pending')
    priority = db.Column(db.String(20))
    assigned_to = db.Column(db.String(100))
    due_date = db.Column(db.DateTime)
    notes = db.Column(db.Text)

class RequestDetailsCompleted(db.Model):
    __bind_key__ = 'completed_cases'  # Use completed_cases database
    __tablename__ = 'request_details'
    
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.String(50), unique=True, nullable=False)
    case_id = db.Column(db.String(50), db.ForeignKey('case_details.case_id'), nullable=False)
    request_type = db.Column(db.String(100), nullable=False)
    request_description = db.Column(db.Text)
    requested_by = db.Column(db.String(100))
    request_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='Completed')
    priority = db.Column(db.String(20))
    assigned_to = db.Column(db.String(100))
    due_date = db.Column(db.DateTime)
    completed_date = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)