from app import db
from datetime import datetime

class CaseDetailsActive(db.Model):
    __bind_key__ = 'active_cases'  # Use active_cases database
    __tablename__ = 'case_details'
    
    id = db.Column(db.Integer, primary_key=True)
    # Non-editable columns
    case_id = db.Column(db.String(50), unique=True, nullable=False)
    tracking_id = db.Column(db.String(50), unique=True, nullable=False)
    issue_type = db.Column(db.String(100), nullable=False)
    
    # Listbox input columns
    case_status = db.Column(db.String(50), default='New')
    maker = db.Column(db.String(100))
    checker = db.Column(db.String(100))
    
    # Free text editable columns
    maker_comments = db.Column(db.Text)
    checker_comments = db.Column(db.Text)
    
    # Additional fields
    priority = db.Column(db.String(20), default='Medium')
    created_by = db.Column(db.String(100))
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    updated_date = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    due_date = db.Column(db.DateTime)
    
    # Relationship with request details (one-to-many)
    requests = db.relationship('RequestDetailsActive', backref='case', lazy=True, cascade='all, delete-orphan')

class CaseDetailsCompleted(db.Model):
    __bind_key__ = 'completed_cases'  # Use completed_cases database
    __tablename__ = 'case_details'
    
    id = db.Column(db.Integer, primary_key=True)
    # Non-editable columns
    case_id = db.Column(db.String(50), unique=True, nullable=False)
    tracking_id = db.Column(db.String(50), unique=True, nullable=False)
    issue_type = db.Column(db.String(100), nullable=False)
    
    # Listbox input columns
    case_status = db.Column(db.String(50), default='Completed')
    maker = db.Column(db.String(100))
    checker = db.Column(db.String(100))
    
    # Free text editable columns
    maker_comments = db.Column(db.Text)
    checker_comments = db.Column(db.Text)
    
    # Additional fields
    priority = db.Column(db.String(20), default='Medium')
    created_by = db.Column(db.String(100))
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    completed_date = db.Column(db.DateTime, default=datetime.utcnow)
    due_date = db.Column(db.DateTime)
    
    # Relationship with request details (one-to-many)
    requests = db.relationship('RequestDetailsCompleted', backref='case', lazy=True, cascade='all, delete-orphan')